#include "Debug/ProtoDebug.h"

// 🔹 Define the log category declared in ProtoDebug.h
DEFINE_LOG_CATEGORY(LogProto);
