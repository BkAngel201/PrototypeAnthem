// Fill out your copyright notice in the Description page of Project Settings.


#include "Managers/ProtoWidgetManager.h"

#include "Blueprint/UserWidget.h"

void UProtoWidgetManager::Initialize(APlayerController* InOwner)
{
	UE_LOG(LogTemp, Warning, TEXT("[WidgetManager] Initialized for: %s"), *GetNameSafe(InOwner));
	
	Owner = InOwner;
}

UUserWidget* UProtoWidgetManager::ShowWidget(TSubclassOf<UUserWidget> WidgetClass, int32 ZOrder)
{
	UE_LOG(LogTemp, Warning, TEXT("[WidgetManager] Showing widget: %s | Owner: %s"), 
		*GetNameSafe(WidgetClass), 
		*GetNameSafe(Owner));
	if (ActiveWidget)
	{
		ActiveWidget->RemoveFromParent();
		ActiveWidget = nullptr;
	}

	if (!WidgetClass)
		return nullptr;

	UWorld* World = GetWorld();
	if (!World)
		return nullptr;

	if (Owner)
	{
		ActiveWidget = CreateWidget<UUserWidget>(Owner, WidgetClass);
		if (ActiveWidget)
		{
			ActiveWidget->AddToViewport(ZOrder);
			ActiveWidget->SynchronizeProperties(); // ensures widget bindings are live
			ActiveWidget->ForceLayoutPrepass();  // forces render tree setup
		}
	}
	return ActiveWidget;
}

void UProtoWidgetManager::RemoveCurrentWidget()
{
	if (ActiveWidget)
	{
		ActiveWidget->RemoveFromParent();
		ActiveWidget = nullptr;
	}
}
