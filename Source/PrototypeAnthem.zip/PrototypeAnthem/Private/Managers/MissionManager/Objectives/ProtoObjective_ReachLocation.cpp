// Fill out your copyright notice in the Description page of Project Settings.


#include "Managers/MissionManager/Objectives/ProtoObjective_ReachLocation.h"

#include "Debug/ProtoDebug.h"
#include "Managers/MissionManager/ProtoMissionManager.h"
#include "Managers/MissionManager/Objectives/Actors/ProtoMission_TargetLocation.h"

UProtoObjective_ReachLocation::UProtoObjective_ReachLocation()
{
	TargetActorClass = AProtoMission_TargetLocation::StaticClass();
	FTransform SpawnTransform;
	SpawnTransform.SetLocation(FVector(1960.000000,210.000000,0.000000));
	TargetSpawnTransform = SpawnTransform;
}

void UProtoObjective_ReachLocation::StartObjective_Implementation()
{
	Super::StartObjective_Implementation();
	
	if (TargetActorClass != nullptr)
	{
		if (Owner_MissionManager && Owner_MissionManager->GetWorld() && Owner_MissionManager->GetWorld()->GetAuthGameMode())
		{
			TargetActor = Owner_MissionManager->GetWorld()->SpawnActor<AProtoMission_TargetLocation>(TargetActorClass, TargetSpawnTransform);
			if (TargetActor)
			{
				DEBUG_LOG("Objective_ReachLocation: Spawning Actor() %s", *GetNameSafe(TargetActor));
				TargetActor->OnTargetReached.AddDynamic(this, &UProtoObjective_ReachLocation::OnTargetReached);
				DEBUG_LOG("Objective_ReachLocation: Binding Finished");
			}
		}
		else
		{
			DEBUG_LOG("❌ No valid world or GameMode in Objective_ReachLocation for %s", *GetName());
		}
	}
}

void UProtoObjective_ReachLocation::OnTargetReached(AActor* Player)
{
	CompleteObjective();
	if (TargetActor && !TargetActor->IsPendingKillPending())
	{
		TargetActor->Destroy();
		TargetActor = nullptr;
	}
}
