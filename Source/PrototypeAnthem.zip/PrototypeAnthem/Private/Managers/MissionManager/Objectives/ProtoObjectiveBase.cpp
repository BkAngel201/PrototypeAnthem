// Fill out your copyright notice in the Description page of Project Settings.


#include "Managers/MissionManager/Objectives/ProtoObjectiveBase.h"

#include "Core/ProtoTypes.h"
#include "Debug/ProtoDebug.h"
#include "Managers/MissionManager/ProtoMissionManager.h"

void UProtoObjectiveBase::SetObjectiveState(EMissionState NewState)
{
	ObjectiveState = NewState;
	OnObjectiveStateChanged.Broadcast(NewState);
}

void UProtoObjectiveBase::StartObjective_Implementation()
{
	SetObjectiveState(EMissionState::Active);
	OnObjectiveStarted();
	DEBUG_LOG("Objective: StartObjective()");
}

void UProtoObjectiveBase::CompleteObjective_Implementation()
{
	SetObjectiveState(EMissionState::Completed);
 	OnObjectiveCompleted();
}


void UProtoObjectiveBase::FailObjective_Implementation()
{
	SetObjectiveState(EMissionState::Failed);
	OnObjectiveFailed();
}

