// Fill out your copyright notice in the Description page of Project Settings.

#include "Managers/MissionManager/Objectives/Actors/ProtoMission_TargetLocation.h"

#include "Components/SphereComponent.h"
#include "Debug/ProtoDebug.h"
#include "GameFramework/Character.h"

// Sets default values
AProtoMission_TargetLocation::AProtoMission_TargetLocation()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = true;
	bAlwaysRelevant = true;

	SphereTrigger = CreateDefaultSubobject<USphereComponent>(TEXT("SphereTrigger"));
	RootComponent = SphereTrigger;
	SphereTrigger->InitSphereRadius(200.0f);
	SphereTrigger->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	
	SphereTrigger->SetHiddenInGame(false);
	SphereTrigger->SetVisibility(true);
	SphereTrigger->bDrawOnlyIfSelected = false;
}

void AProtoMission_TargetLocation::BeginPlay()
{
	Super::BeginPlay();
	SphereTrigger->OnComponentBeginOverlap.AddDynamic(this, &AProtoMission_TargetLocation::HandleOverlap);
}

void AProtoMission_TargetLocation::HandleOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (OtherActor && OtherActor->IsA(ACharacter::StaticClass()))
	{
		DEBUG_LOG("TargetLocation : NotifyActorBeginOverlap %s", *GetNameSafe(OtherActor));
		OnTargetReached.Broadcast(OtherActor);
	}
}


