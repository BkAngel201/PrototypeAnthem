// Fill out your copyright notice in the Description page of Project Settings.


#include "Managers/MissionManager/ProtoMissionManager.h"

#include "Core/ProtoGameState.h"
#include "Core/ProtoTypes.h"
#include "Core/GameModes/ProtoMission_GM.h"
#include "Debug/ProtoDebug.h"
#include "Kismet/GameplayStatics.h"
#include "Managers/MissionManager/Objectives/ProtoObjective_ReachLocation.h"

UProtoMissionManager::UProtoMissionManager()
{
}

void UProtoMissionManager::Initialize(AProtoGameState* InMissionGM)
{
	DEBUG_LOG("Mission Manager: Initialize()");
	Owner_GS = InMissionGM;
}

void UProtoMissionManager::SetMissionState(EMissionState NewState)
{
	DEBUG_LOG("Mission Manager: SetMissionState() - MissionState set to %d", (uint8)NewState);
	CurrentMissionState = NewState;
	OnLocalMissionStateChanged.Broadcast(CurrentMissionState);
}

void UProtoMissionManager::StartMission()
{
	if (!Owner_GS || !Owner_GS->HasAuthority()) return;
	StartMissionCountdown();
}

void UProtoMissionManager::StartMissionCountdown()
{
	if (!Owner_GS || !Owner_GS->HasAuthority()) return;
	SetMissionState(EMissionState::Countdown);
	if (Owner_GS)
	{
		Owner_GS->GetWorldTimerManager().SetTimer(CountdownHandle, this, &UProtoMissionManager::ActivateMission, 2.0f, false);
		DEBUG_LOG("Mission Manager: Timer valid? %d", Owner_GS->GetWorldTimerManager().IsTimerActive(CountdownHandle));
	}
}

void UProtoMissionManager::ActivateMission()
{
	if (!Owner_GS || !Owner_GS->HasAuthority()) return;
	SetMissionState(EMissionState::Active);
	StartObjectives();
}

void UProtoMissionManager::StartObjectives()
{
	if (!Owner_GS || !Owner_GS->HasAuthority()) return;
	auto* Objective = NewObject<UProtoObjective_ReachLocation>(this);
	Objective->Owner_MissionManager = this;
	Objective->OnObjectiveStateChanged.AddDynamic(this, &UProtoMissionManager::HandleObjectiveStateChanged);
	ActiveObjectives.Add(Objective);
	Objective->StartObjective();
	DEBUG_LOG("Mission Manager: StartObjectives()");
}

void UProtoMissionManager::HandleObjectiveStateChanged(EMissionState NewState)
{
	if (NewState == EMissionState::Completed)
	{
		CheckIfAllObjectivesCompleted();
	}
}

void UProtoMissionManager::CheckIfAllObjectivesCompleted()
{
	for (auto Objective : ActiveObjectives)
	{
		if (Objective->ObjectiveState != EMissionState::Completed)
		{
			return;
		}
	}
	CompleteMission();
}

void UProtoMissionManager::CompleteMission()
{
	if (!Owner_GS || !Owner_GS->HasAuthority()) return;
	SetMissionState(EMissionState::Completed);
	if (Owner_GS)
	{
		AProtoMission_GM* GM = Cast<AProtoMission_GM>(UGameplayStatics::GetGameMode(Owner_GS->GetWorld()));
		
		Owner_GS->GetWorldTimerManager().SetTimer(TravelHandle, GM, &AProtoMission_GM::TravelToLobby, 2, false);
		DEBUG_LOG("Mission Manager: Timer valid? %d", Owner_GS->GetWorldTimerManager().IsTimerActive(TravelHandle));
	}
}

void UProtoMissionManager::FailMission()
{
	if (!Owner_GS || !Owner_GS->HasAuthority()) return;
	SetMissionState(EMissionState::Failed);
}
