// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/ProtoPlayerController.h"

#include "Blueprint/UserWidget.h"
#include "Core/ProtoGameState.h"
#include "Core/ProtoPlayerState.h"
#include "Core/GameModes/ProtoLobby_GM.h"
#include "Debug/ProtoDebug.h"
#include "Managers/ProtoWidgetManager.h"


AProtoPlayerController::AProtoPlayerController()
{
	WidgetManager = nullptr;
}

void AProtoPlayerController::BeginPlay()
{
	Super::BeginPlay();
	
	if (!IsLocalController())
	{
		return; // Don't create UI on server or remote clients
	}

	if (!WidgetManager)
	{
		WidgetManager = NewObject<UProtoWidgetManager>(this);
		WidgetManager->Initialize(this);
	}
	
	FString  Mapname = GetWorld()->GetMapName();

	if (Mapname.Contains("Lobby"))
	{
		ShowLobbyUI();
	}
	else if (Mapname.Contains("Mission"))
	{
		ShowMissionHUD();
	}
}

void AProtoPlayerController::ShowLobbyUI()
{
	if (!LobbyWidgetClass || !IsLocalController()) return;

	if (WidgetManager && WidgetManager->ShowWidget(LobbyWidgetClass))
	{
		if (AProtoGameState* GS = GetWorld()->GetGameState<AProtoGameState>())
		{
			DEBUG_LOG("Deferred UI binding complete.");
		}
	}
}

void AProtoPlayerController::ShowMissionHUD()
{
	if (!MissionHUDClass || !IsLocalController()) return;

	if (WidgetManager && WidgetManager->ShowWidget(MissionHUDClass))
    {
        DEBUG_LOG("Mission HUD created");
    }
}

void AProtoPlayerController::Server_SelectRole_Implementation(ERoleType InRole)
{
	NET_LOG("Server_SelectRole");
	if (AProtoPlayerState* PS = GetPlayerState<AProtoPlayerState>())
	{
		DEBUG_LOG("Server_SelectRole called: %d", (uint8)InRole);
		PS->SelectedRole = InRole;
		PS->OnLobbyDataChanged.Broadcast(PS);
	}
}

void AProtoPlayerController::Server_SetReady_Implementation(bool bInReady)
{
	NET_LOG("Server_SetReady");
	if (AProtoPlayerState* PS = GetPlayerState<AProtoPlayerState>())
	{
		DEBUG_LOG("Server_SetReady called: %s", bInReady ? TEXT("true") : TEXT("false"));
		PS->bIsReady = bInReady;
		PS->OnLobbyDataChanged.Broadcast(PS);

		if (HasAuthority())
		{
			if (AProtoLobby_GM* GM = GetWorld()->GetAuthGameMode<AProtoLobby_GM>())
			{
				GM->CheckAllPlayersReady();
			}
		}
	}
}


void AProtoPlayerController::SelectRole(ERoleType NewRole)
{
	DEBUG_LOG("Client calling SelectRole: %d", (uint8)NewRole);
	Server_SelectRole(NewRole);
}

void AProtoPlayerController::SetReady(bool bNewReady)
{
	DEBUG_LOG("Client calling SetReady: %s", bNewReady ? TEXT("true") : TEXT("false"));
	Server_SetReady(bNewReady);
}

void AProtoPlayerController::ToggleReady()
{
	if (AProtoPlayerState* PS = GetPlayerState<AProtoPlayerState>())
	{
		const bool bNewReady = !PS->bIsReady;
		DEBUG_LOG("Toggling Ready → %s", bNewReady ? TEXT("true") : TEXT("false"));
		Server_SetReady(bNewReady);
	}
}


