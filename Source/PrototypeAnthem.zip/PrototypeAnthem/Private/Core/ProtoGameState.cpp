// Fill out your copyright notice in the Description page of Project Settings.


#include "Core/ProtoGameState.h"

#include "Managers/MissionManager/ProtoMissionManager.h"
#include "Debug/ProtoDebug.h"
#include "Net/UnrealNetwork.h"
#include "Core/ProtoTypes.h"

AProtoGameState::AProtoGameState()
{
}

void AProtoGameState::SetupMissionManager()
{
	UProtoMissionManager* newMissionManager = NewObject<UProtoMissionManager>(this);
	MissionManager = newMissionManager;
	MissionManager->OnLocalMissionStateChanged.AddDynamic(this, &AProtoGameState::HandleMissionStateChanged);
	MissionManager->Initialize(this);
	MissionManager->StartMission();
}

void AProtoGameState::AddPlayerState(APlayerState* PlayerState)
{
	Super::AddPlayerState(PlayerState);
	NET_LOG("PlayerArray changed (Player Added)");
	OnPlayerArrayChanged.Broadcast(this);
}

void AProtoGameState::RemovePlayerState(APlayerState* PlayerState)
{
	Super::RemovePlayerState(PlayerState);
	NET_LOG("PlayerArray changed (Player Removed)");
	OnPlayerArrayChanged.Broadcast(this);
}

void AProtoGameState::OnRep_CountdownEndTime()
{
	NET_LOG("OnRep_CountdownTime");
	DEBUG_LOG("OnRep_CountdownTime: %f", CountdownEndTime);
	OnScreenCountdownStarted.Broadcast(CountdownEndTime);
}

void AProtoGameState::OnRep_MissionState()
{
	DEBUG_LOG("Game State: OnRep_MissionState() - MissionState Changed");
	OnMissionStateChanged.Broadcast(MissionState);
}

void AProtoGameState::HandleMissionStateChanged(EMissionState NewState)
{
	DEBUG_LOG("Mission GM: HandleMissionStateChanged() - MissionState Changed");
	MissionState = NewState; // replicated
	ForceNetUpdate();
	OnRep_MissionState();
}

void AProtoGameState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(AProtoGameState, CountdownEndTime);
	DOREPLIFETIME(AProtoGameState, MissionState);
}
