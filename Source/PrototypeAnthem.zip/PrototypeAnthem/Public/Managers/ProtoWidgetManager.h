// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "ProtoWidgetManager.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPEANTHEM_API UProtoWidgetManager : public UObject
{
	GENERATED_BODY()

public:
	/** Set up manager with owning controller */
	void Initialize(APlayerController* InOwner);

	/** Creates a new widget, removes the previous one */
	UFUNCTION(BlueprintCallable, Category="UI")
	UUserWidget* ShowWidget(TSubclassOf<UUserWidget> WidgetClass, int32 ZOrder = 0);

	/** Removes current main widget */
	UFUNCTION(BlueprintCallable, Category="UI")
	void RemoveCurrentWidget();


	/** Returns current active widget */
	UFUNCTION(BlueprintCallable, Category="UI")
	UUserWidget* GetActiveWidget() const { return ActiveWidget; }

private:
	UPROPERTY()
	APlayerController* Owner;

	UPROPERTY()
	UUserWidget* ActiveWidget;
};
