// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ProtoMissionManager.generated.h"

class UProtoObjectiveBase;
class AProtoGameState;
enum class EMissionState: uint8;
/**
 * 
 */

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnLocalMissionStateChanged, EMissionState, NewState);

UCLASS()
class PROTOTYPEANTHEM_API UProtoMissionManager : public UObject
{
	GENERATED_BODY()
public:
	UProtoMissionManager();

	UPROPERTY()
	TArray<UProtoObjectiveBase*> ActiveObjectives;
	UPROPERTY(BlueprintReadOnly, Category="Mission")
	EMissionState CurrentMissionState;
	UPROPERTY(BlueprintAssignable)
	FOnLocalMissionStateChanged OnLocalMissionStateChanged;
	

	UFUNCTION()
	void CheckIfAllObjectivesCompleted();
	UFUNCTION()
	void HandleObjectiveStateChanged(EMissionState NewState);

	
	UFUNCTION()
	void Initialize(AProtoGameState* InMissionGM);

	UFUNCTION()
	void StartObjectives();
	
	UFUNCTION(BlueprintCallable, Category="Mission")
	void StartMission();
	
	UFUNCTION()
	void SetMissionState(EMissionState NewState);
	UFUNCTION()
	void StartMissionCountdown();
	UFUNCTION()
	void ActivateMission();
	UFUNCTION()
	void CompleteMission();
	UFUNCTION()
	void FailMission();


private:
	UPROPERTY()
	AProtoGameState* Owner_GS;
	
	FTimerHandle CountdownHandle;
	FTimerHandle ActiveHandle;
	FTimerHandle TravelHandle;
};
