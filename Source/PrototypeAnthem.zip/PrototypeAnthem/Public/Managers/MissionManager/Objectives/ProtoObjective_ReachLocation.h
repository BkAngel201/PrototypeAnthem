// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Managers/MissionManager/Objectives/ProtoObjectiveBase.h"
#include "ProtoObjective_ReachLocation.generated.h"

class AProtoMission_TargetLocation;
/**
 * 
 */

UCLASS()
class PROTOTYPEANTHEM_API UProtoObjective_ReachLocation : public UProtoObjectiveBase
{
	GENERATED_BODY()

public:
	UProtoObjective_ReachLocation();
	UPROPERTY(EditAnywhere)
	FVector Location;
	UPROPERTY(EditAnywhere)
	float Radius;
	UPROPERTY(EditAnywhere)
	TSubclassOf<AProtoMission_TargetLocation> TargetActorClass;
	UPROPERTY(EditAnywhere)
	AProtoMission_TargetLocation* TargetActor;
	UPROPERTY(EditAnywhere)
	FTransform TargetSpawnTransform;

	void StartObjective_Implementation();
	UFUNCTION()
	void OnTargetReached(AActor* Player);
};
