// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ProtoObjectiveBase.generated.h"

class UProtoMissionManager;
class AProtoMission_GM;
enum class EMissionState : uint8;
/**
 * 
 */

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnObjectiveStateChanged, EMissionState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnObjectiveProgress, int32, Current, int32, Total);

UCLASS()
class PROTOTYPEANTHEM_API UProtoObjectiveBase : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	EMissionState ObjectiveState;
	UPROPERTY()
	FText ObjectiveName;
	UPROPERTY()
	FText ObjectiveDescription;

	UPROPERTY()
	AProtoMission_GM* Owning_GM;
	UPROPERTY()
	UProtoMissionManager* Owner_MissionManager;

	UFUNCTION(BlueprintImplementableEvent)
	void OnObjectiveStarted();
	UFUNCTION(BlueprintImplementableEvent)
	void OnObjectiveCompleted();
	UFUNCTION(BlueprintImplementableEvent)
	void OnObjectiveFailed();

	UPROPERTY(BlueprintAssignable)
	FOnObjectiveStateChanged OnObjectiveStateChanged;
	UPROPERTY(BlueprintAssignable)
	FOnObjectiveProgress OnObjectiveProgress;

	UFUNCTION(BlueprintCallable)
	void SetObjectiveState(EMissionState NewState);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Objective")
	void StartObjective();
	virtual void StartObjective_Implementation();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Objective")
	void CompleteObjective();
	virtual void CompleteObjective_Implementation();
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Objective")
	void FailObjective();
	virtual void FailObjective_Implementation();
	
};
