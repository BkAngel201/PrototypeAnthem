// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Managers/MissionManager/Objectives/ProtoObjectiveBase.h"
#include "ProtoObjective_KillEnemies.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPEANTHEM_API UProtoObjective_KillEnemies : public UProtoObjectiveBase
{
	GENERATED_BODY()
	
};
