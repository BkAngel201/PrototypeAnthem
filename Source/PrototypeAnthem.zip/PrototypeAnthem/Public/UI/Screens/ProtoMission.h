// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/Core/ProtoWidgetBase.h"
#include "ProtoMission.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPEANTHEM_API UProtoMission : public UProtoWidgetBase
{
	GENERATED_BODY()

public:

};
