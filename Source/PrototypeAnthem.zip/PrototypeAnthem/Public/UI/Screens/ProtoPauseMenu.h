// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/Core/ProtoWidgetBase.h"
#include "ProtoPauseMenu.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPEANTHEM_API UProtoPauseMenu : public UProtoWidgetBase
{
	GENERATED_BODY()
	
};
