// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "WBP_ProtoMission.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPEANTHEM_API UWBP_ProtoMission : public UUserWidget
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintImplementableEvent, Category="Mission")
	void StartCountdown(float Time);
};
