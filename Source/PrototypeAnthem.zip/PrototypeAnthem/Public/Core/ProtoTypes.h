#pragma once

#include "CoreMinimal.h"
#include "ProtoTypes.generated.h"

UENUM(BlueprintType)
enum class EMissionState : uint8
{
	Inactive   UMETA(DisplayName = "Inactive",  ToolTip = "Mission system is idle or not yet initialized."),
	Countdown  UMETA(DisplayName = "Countdown", ToolTip = "Mission is preparing to start. Players see a countdown before activation."),
	Active     UMETA(DisplayName = "Active",    ToolTip = "Mission is currently running. Objectives are being tracked and updated."),
	Completed  UMETA(DisplayName = "Completed", ToolTip = "All objectives are finished and the mission has succeeded."),
	Failed     UMETA(DisplayName = "Failed",    ToolTip = "Mission ended unsuccessfully or was aborted before completion.")
};

UENUM(BlueprintType)
enum class ERoleType : uint8
{
	None      UMETA(DisplayName="None", ToolTip="Unassigned or spectator role"),
	Tank      UMETA(DisplayName="Tank", ToolTip="High durability frontline"),
	DPS       UMETA(DisplayName="DPS", ToolTip="Damage dealer role"),
	Utility   UMETA(DisplayName="Utility", ToolTip="Support or control role")
};

UCLASS()
class UProtoTypeHelpers : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** Returns a readable mission state string */
	UFUNCTION(BlueprintPure, Category = "Proto|Helpers")
	static FText GetMissionStateText(EMissionState State);

	/** Returns a readable role name string */
	UFUNCTION(BlueprintPure, Category = "Proto|Helpers")
	static FText GetRoleTypeText(ERoleType Role);
};