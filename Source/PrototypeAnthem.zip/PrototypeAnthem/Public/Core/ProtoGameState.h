// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "ProtoGameState.generated.h"

/**
 * 
 */
enum class EMissionState: uint8;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPlayerArrayChanged, AProtoGameState*, GameStateRef);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnScreenCountdownStarted, float, CountdownEndTime);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMissionStateChanged, EMissionState, NewState);

UCLASS()
class PROTOTYPEANTHEM_API AProtoGameState : public AGameStateBase
{
	GENERATED_BODY()

public:
	AProtoGameState();
	void SetupMissionManager();
	virtual void AddPlayerState(APlayerState* PlayerState) override;
	virtual void RemovePlayerState(APlayerState* PlayerState) override;

	UPROPERTY(BlueprintAssignable, Category="Events | Lobby")
	FOnPlayerArrayChanged OnPlayerArrayChanged;
	UPROPERTY(BlueprintAssignable, Category="Events | Mission")
	FOnScreenCountdownStarted OnScreenCountdownStarted;
	UPROPERTY(BlueprintAssignable, Category="Events | Mission")
	FOnMissionStateChanged OnMissionStateChanged;

	UPROPERTY(ReplicatedUsing=OnRep_CountdownEndTime, BlueprintReadOnly, Category="Mission")
	float CountdownEndTime;

	UPROPERTY(ReplicatedUsing=OnRep_MissionState)
	EMissionState MissionState;

	UPROPERTY(BlueprintReadOnly, Category="Mission", meta=(AllowPrivateAccess="true"))
	UProtoMissionManager*  MissionManager;
	
	UFUNCTION(BlueprintPure, Category="Mission")
	UProtoMissionManager* GetMissionManager() const { return MissionManager; }

	// --- Networking ---
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	
	UFUNCTION()
	void OnRep_CountdownEndTime();
	
	UFUNCTION()
	void OnRep_MissionState();
	UFUNCTION()
	void HandleMissionStateChanged(EMissionState NewState);
};
